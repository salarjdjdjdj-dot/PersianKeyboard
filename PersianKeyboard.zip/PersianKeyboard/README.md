# کیبورد فارسی (Persian Keyboard)

پروژه‌ی اندروید کامل و تازه‌ساز، سورس ۱۰۰٪ در دسترس (Kotlin + XML)، بدون هیچ فایل کامپایل‌شده یا دیکامپایل‌شده.

## چیدمان فایل‌ها

```
PersianKeyboard/
├── build.gradle                     (تنظیمات سطح پروژه)
├── settings.gradle
└── app/
    ├── build.gradle                 (minSdk 26, Kotlin)
    └── src/main/
        ├── AndroidManifest.xml      (ثبت سرویس IME)
        ├── java/key/boo/ard/ali/
        │   └── PersianKeyboardService.kt   (منطق اصلی کیبورد)
        └── res/
            ├── xml/
            │   ├── method.xml                   (متادیتای IME)
            │   ├── popup_template.xml           (قالب پاپ‌آپ حروف اضافه)
            │   ├── keyboard_persian_letters.xml (صفحه حروف فارسی)
            │   └── keyboard_symbols_123.xml     (صفحه اعداد و نمادها)
            ├── layout/
            │   └── keyboard_view.xml            (کانتینر KeyboardView)
            ├── drawable/
            │   ├── key_background.xml           (سلکتور فشردن آنی، بدون ripple)
            │   ├── key_bg_normal.xml
            │   ├── key_bg_pressed.xml
            │   ├── ic_backspace.xml
            │   ├── ic_enter.xml
            │   └── ...آیکون لانچر
            └── values/colors.xml
```

## چرا سریع و بدون هنگه

1. **پیش‌نمایش کلید غیرفعاله** (`isPreviewEnabled = false`) — پیش‌نمایش هر کلید یه `PopupWindow` جداست که هر بار باز و بسته می‌شه؛ حذفش بیشترین تأثیر رو روی حس نرمی و سرعت داره.
2. **بدون ripple و بدون فید** — `key_background.xml` با `enterFadeDuration="0"` و `exitFadeDuration="0"` تنظیم شده، یعنی رنگ کلید فوراً و بدون هیچ انیمیشن محوشوندگی عوض می‌شه.
3. **جابه‌جایی صفحه بدون ترنزیشن** — تعویض بین صفحه حروف و اعداد فقط `keyboardView.keyboard = ...` هست، بدون فید یا اسلاید که تأخیر مصنوعی اضافه کنه.
4. **منطق `onKey` مینیمال** — از `when` ساده به‌جای سوییچ سنگین استفاده شده و مستقیم `InputConnection` رو صدا می‌زنه.

## نحوه اجرا

1. [Android Studio](https://developer.android.com/studio) رو نصب کن.
2. `File → Open` و پوشه `PersianKeyboard` رو انتخاب کن (Android Studio خودش Gradle Wrapper لازم رو دانلود و ست‌آپ می‌کنه).
3. صبر کن Gradle sync تموم بشه.
4. گوشی رو با USB وصل کن (یا امولاتور بزن) و دکمه Run (▶) رو بزن.
5. بعد از نصب، برو به **تنظیمات گوشی → مدیریت کیبوردها** و کیبورد فارسی رو فعال کن، بعد از کیبورد پیش‌فرض بهش سوییچ کن.

## توسعه بعدی (اختیاری)

- برای caps/شیفت واقعی حروف، باید منطق حالت بزرگ/کوچک به `onKey` اضافه بشه (فارسی حرف بزرگ/کوچک نداره، پس این بخش عمداً ساده نگه داشته شده).
- اگه بخوای صدای کلیک یا لرزش (haptic) اضافه بشه، توصیه می‌کنم فقط از `Vibrator` با تاخیر خیلی کوتاه (زیر ۱۰ میلی‌ثانیه) استفاده کنی که حس سرعت از بین نره.
