package key.boo.ard.ali

import android.inputmethodservice.InputMethodService
import android.inputmethodservice.Keyboard
import android.inputmethodservice.KeyboardView
import android.inputmethodservice.KeyboardView.OnKeyboardActionListener
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputConnection

/**
 * سرویس کیبورد فارسی.
 *
 * طراحی برای سریع‌ترین و نرم‌ترین حالت ممکن:
 * - پیش‌نمایش کلید (preview popup) کاملاً غیرفعاله چون خودش یه پنجره جدا رندر می‌کنه و کندی ایجاد می‌کنه.
 * - پس‌زمینه کلید با state-list ساده (بدون ripple و بدون fade) عوض می‌شه، یعنی واکنش فشردن آنی و بدون تاخیره.
 * - جابه‌جایی بین صفحه حروف/اعداد فقط با عوض کردن آبجکت Keyboard انجام می‌شه؛ هیچ انیمیشن ترنزیشنی
 *   بین صفحات نداریم چون خودش یه‌جور تاخیر مصنوعی به تایپ اضافه می‌کنه.
 */
class PersianKeyboardService : InputMethodService(), OnKeyboardActionListener {

    private lateinit var keyboardView: KeyboardView
    private lateinit var lettersKeyboard: Keyboard
    private lateinit var symbolsKeyboard: Keyboard

    private var isSymbolsMode = false

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null) as KeyboardView

        lettersKeyboard = Keyboard(this, R.xml.keyboard_persian_letters)
        symbolsKeyboard = Keyboard(this, R.xml.keyboard_symbols_123)

        // پیش‌نمایش کلید رو خاموش می‌کنیم؛ این تنها چیزیه که واقعاً باعث حس کندی توی کیبوردهای
        // دست‌ساز میشه، چون هر بار یه PopupWindow جدا باز/بسته می‌کنه.
        keyboardView.isPreviewEnabled = false

        keyboardView.keyboard = lettersKeyboard
        keyboardView.setOnKeyboardActionListener(this)

        return keyboardView
    }

    override fun onKey(primaryCode: Int, keyCodes: IntArray?) {
        val ic: InputConnection = currentInputConnection ?: return

        when (primaryCode) {
            Keyboard.KEYCODE_DELETE -> {
                ic.deleteSurroundingText(1, 0)
            }
            Keyboard.KEYCODE_DONE -> {
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
            }
            Keyboard.KEYCODE_MODE_CHANGE -> {
                switchKeyboardPage()
            }
            else -> {
                val code = primaryCode.toChar()
                ic.commitText(code.toString(), 1)
            }
        }
    }

    private fun switchKeyboardPage() {
        isSymbolsMode = !isSymbolsMode
        keyboardView.keyboard = if (isSymbolsMode) symbolsKeyboard else lettersKeyboard
    }

    // بقیه‌ی کال‌بک‌های اجباری اینترفیس؛ چیزی برای انجام دادن ندارن اما باید خالی override بشن
    override fun onPress(primaryCode: Int) {}
    override fun onRelease(primaryCode: Int) {}
    override fun onText(text: CharSequence?) {}
    override fun swipeLeft() {}
    override fun swipeRight() {}
    override fun swipeDown() {}
    override fun swipeUp() {}
}
